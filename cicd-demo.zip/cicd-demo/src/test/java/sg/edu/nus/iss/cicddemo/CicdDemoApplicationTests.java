package sg.edu.nus.iss.cicddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicdDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
